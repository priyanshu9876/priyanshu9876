# Inventory Dashboard (React + Node.js)

300 products ka data pehle se loaded hai. Add / edit / delete, search, filter, sort, pagination, histogram, charts, Excel import / export.

- Backend: Node.js + Express (`server/`) — data `server/data/products.json` me save hota hai
- Frontend: React + Vite + Recharts (`client/`)
- Excel sirf Import / Export ke liye (`sample-data/products_300.xlsx` import karke test kar sakte ho)

## Chalana

```bash
npm run install:all
npm run build
npm start          # http://localhost:5000
```

Development (live reload) ke liye 2 terminal:
```bash
npm run dev:server   # http://localhost:5000
npm run dev:client   # http://localhost:5173
```

## Render par deploy

Build Command: `npm run build`   |   Start Command: `npm start`

Free plan par disk temporary hota hai: restart/redeploy par data wapas 300 sample products par aa jata hai.
Permanent data ke liye paid plan + disk lo, aur `render.yaml` ke commented lines (`DATA_DIR=/var/data`) uncomment karo.
Free plan par deploy se pehle Export Excel kar lo, baad me Import se wapas daal do.

Is app me login nahi hai, jiske paas URL ho wo data badal sakta hai.

## API

| Method | URL | Kaam |
| --- | --- | --- |
| GET | /api/products | sab products |
| POST | /api/products | naya product (ID auto) |
| PUT | /api/products/:id | edit |
| DELETE | /api/products/:id | delete |
| GET | /api/export | Excel download |
| POST | /api/import | Excel upload (sab replace) |

Status auto: stock 0 = Out of Stock, 1-10 = Low Stock, baaki Active.

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const store = require('./store');
const excel = require('./excelIO');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: '1mb' }));

const wrap = (fn) => (req, res, next) => Promise.resolve().then(() => fn(req, res, next)).catch(next);
const parseId = (req) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) throw Object.assign(new Error('Invalid product id'), { status: 400 });
  return id;
};

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.get('/api/products', wrap((req, res) => res.json(store.list())));

app.post('/api/products', wrap((req, res) => res.status(201).json(store.create(req.body || {}))));

app.put('/api/products/:id', wrap((req, res) => res.json(store.update(parseId(req), req.body || {}))));

app.delete('/api/products/:id', wrap((req, res) => {
  store.remove(parseId(req));
  res.status(204).end();
}));

app.get('/api/export', wrap(async (req, res) => {
  const buf = await excel.toBuffer(store.list());
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="products.xlsx"');
  res.send(buf);
}));

app.post(
  '/api/import',
  express.raw({ type: 'application/octet-stream', limit: '10mb' }),
  wrap(async (req, res) => {
    if (!Buffer.isBuffer(req.body) || !req.body.length) {
      throw Object.assign(new Error('File khali hai'), { status: 400 });
    }
    const rawRows = await excel.fromBuffer(req.body);
    res.json(store.importRows(rawRows));
  })
);

// React build (production)
const dist = path.join(__dirname, '..', 'client', 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.use((req, res, next) => {
    if (req.method !== 'GET' || req.path.startsWith('/api')) return next();
    res.sendFile(path.join(dist, 'index.html'));
  });
}

app.use((err, req, res, next) => {
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: err.message || 'Server error' });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

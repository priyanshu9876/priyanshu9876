// Excel import / export only (the live data is in store.js)
const ExcelJS = require('exceljs');

const COLS = ['product_id', 'product_name', 'category', 'price_inr', 'stock_quantity', 'status', 'last_updated'];
const WIDTHS = [12, 30, 16, 12, 16, 14, 14];
const httpError = (status, message) => Object.assign(new Error(message), { status });

const plain = (v) => {
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (v && typeof v === 'object') {
    if ('result' in v) return v.result;
    if ('text' in v) return v.text;
  }
  return v;
};

async function toBuffer(items) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Products', { views: [{ state: 'frozen', ySplit: 1 }] });
  ws.columns = COLS.map((c, i) => ({ header: c, key: c, width: WIDTHS[i] }));
  items.forEach((p) => ws.addRow(p));
  ws.getRow(1).font = { bold: true };
  ws.autoFilter = { from: 'A1', to: 'G1' };
  return Buffer.from(await wb.xlsx.writeBuffer());
}

async function fromBuffer(buffer) {
  const wb = new ExcelJS.Workbook();
  try {
    await wb.xlsx.load(buffer);
  } catch {
    throw httpError(400, 'Ye valid .xlsx file nahi hai');
  }
  const ws = wb.getWorksheet('Products') || wb.worksheets[0];
  if (!ws) throw httpError(400, 'File me koi sheet nahi mili');

  const map = {};
  ws.getRow(1).eachCell((cell, col) => {
    map[String(plain(cell.value)).trim()] = col;
  });
  for (const c of ['product_name', 'category', 'price_inr', 'stock_quantity']) {
    if (!map[c]) throw httpError(400, `Column "${c}" nahi mila (pehli row me headers chahiye)`);
  }

  const rows = [];
  ws.eachRow((row, n) => {
    if (n === 1) return;
    const o = {};
    for (const c of COLS) o[c] = map[c] ? plain(row.getCell(map[c]).value) : undefined;
    rows.push(o);
  });
  return rows;
}

module.exports = { toBuffer, fromBuffer };

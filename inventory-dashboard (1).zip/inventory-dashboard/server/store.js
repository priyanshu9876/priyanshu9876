// Simple JSON-file store. All operations are synchronous, so two requests can never clash.
const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const FILE = path.join(DATA_DIR, 'products.json');
const SEED = path.join(__dirname, 'seed', 'products.json');

const httpError = (status, message) => Object.assign(new Error(message), { status });
const today = () => new Date().toISOString().slice(0, 10);

function statusFor(stock) {
  if (stock <= 0) return 'Out of Stock';
  if (stock <= 10) return 'Low Stock';
  return 'Active';
}

let items = null;

function persist() {
  const text = JSON.stringify(items, null, 1);
  const tmp = FILE + '.tmp';
  try {
    fs.writeFileSync(tmp, text);
    fs.renameSync(tmp, FILE);
  } catch {
    try {
      fs.writeFileSync(FILE, text); // fallback (e.g. Windows rename lock)
    } catch (e) {
      console.error('Disk write failed, data memory me hai:', e.message);
    }
  }
}

function load() {
  if (items) return items;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(FILE)) fs.copyFileSync(SEED, FILE);
  try {
    items = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (!Array.isArray(items)) throw new Error('bad file');
  } catch {
    items = JSON.parse(fs.readFileSync(SEED, 'utf8'));
    persist();
  }
  return items;
}

function clean(input) {
  const name = String(input.product_name ?? '').trim();
  const category = String(input.category ?? '').trim();
  const price = Number(input.price_inr);
  const stock = Number(input.stock_quantity);
  if (!name) throw httpError(400, 'Product name zaroori hai');
  if (!category) throw httpError(400, 'Category zaroori hai');
  if (!Number.isFinite(price) || price < 0) throw httpError(400, 'Price 0 ya usse zyada number hona chahiye');
  if (!Number.isInteger(stock) || stock < 0) throw httpError(400, 'Stock 0 ya usse zyada poora number hona chahiye');
  return { product_name: name, category, price_inr: price, stock_quantity: stock };
}

const nextId = () => load().reduce((m, p) => Math.max(m, p.product_id), 1000) + 1;

function list() {
  return load();
}

function create(input) {
  const data = clean(input);
  const obj = {
    product_id: nextId(),
    ...data,
    status: statusFor(data.stock_quantity),
    last_updated: today(),
  };
  load().push(obj);
  persist();
  return obj;
}

function update(id, input) {
  const data = clean(input);
  const list_ = load();
  const i = list_.findIndex((p) => p.product_id === id);
  if (i < 0) throw httpError(404, `Product ${id} nahi mila`);
  list_[i] = { product_id: id, ...data, status: statusFor(data.stock_quantity), last_updated: today() };
  persist();
  return list_[i];
}

function remove(id) {
  const list_ = load();
  const i = list_.findIndex((p) => p.product_id === id);
  if (i < 0) throw httpError(404, `Product ${id} nahi mila`);
  list_.splice(i, 1);
  persist();
}

// Excel import: replaces everything. Invalid rows are skipped and counted.
function importRows(rawRows) {
  const out = [];
  const used = new Set();
  let skipped = 0;
  const pending = [];
  for (const r of rawRows) {
    let data;
    try {
      data = clean(r);
    } catch {
      skipped++;
      continue;
    }
    const id = Number(r.product_id);
    const row = {
      ...data,
      status: statusFor(data.stock_quantity),
      last_updated: /^\d{4}-\d{2}-\d{2}$/.test(String(r.last_updated ?? '')) ? String(r.last_updated) : today(),
    };
    if (Number.isInteger(id) && id > 0 && !used.has(id)) {
      used.add(id);
      out.push({ product_id: id, ...row });
    } else {
      pending.push(row);
    }
  }
  if (!out.length && !pending.length) throw httpError(400, 'File me koi valid row nahi mili');
  let next = out.reduce((m, p) => Math.max(m, p.product_id), 1000) + 1;
  for (const row of pending) out.push({ product_id: next++, ...row });
  out.sort((a, b) => a.product_id - b.product_id);
  items = out;
  persist();
  return { rows: out.length, skipped };
}

module.exports = { list, create, update, remove, importRows };

const inr = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});
export const formatINR = (n) => inr.format(n);

export function statusFor(stock) {
  if (stock <= 0) return 'Out of Stock';
  if (stock <= 10) return 'Low Stock';
  return 'Active';
}

export function buildBins(values, width) {
  if (!values.length) return [];
  const count = Math.floor(Math.max(...values) / width) + 1;
  const bins = Array.from({ length: count }, (_, i) => ({
    range: `${i * width}–${(i + 1) * width - 1}`,
    count: 0,
  }));
  values.forEach((v) => {
    bins[Math.floor(v / width)].count += 1;
  });
  return bins;
}

export function summary(values) {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return {
    min: s[0],
    max: s[s.length - 1],
    avg: s.reduce((a, b) => a + b, 0) / s.length,
    median: s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2,
  };
}

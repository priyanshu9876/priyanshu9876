async function req(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) {
    let msg = 'Request failed';
    try {
      msg = (await r.json()).error || msg;
    } catch {
      /* ignore */
    }
    throw new Error(msg);
  }
  return r.status === 204 ? null : r.json();
}

const json = (method, body) => ({
  method,
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body),
});

export const api = {
  list: () => req('/api/products'),
  create: (b) => req('/api/products', json('POST', b)),
  update: (id, b) => req(`/api/products/${id}`, json('PUT', b)),
  remove: (id) => req(`/api/products/${id}`, { method: 'DELETE' }),
  importFile: (file) =>
    req('/api/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream' },
      body: file,
    }),
};

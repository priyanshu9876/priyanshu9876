import { useEffect, useMemo, useRef, useState } from 'react';
import { api } from './api.js';
import { formatINR } from './utils.js';
import Charts from './components/Charts.jsx';
import ProductTable from './components/ProductTable.jsx';
import ProductForm from './components/ProductForm.jsx';

export default function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [modal, setModal] = useState(null); // {mode:'add'} | {mode:'edit', product}
  const [toast, setToast] = useState(null);
  const fileRef = useRef(null);

  const notify = (text, type = 'ok') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  const load = async () => {
    try {
      setProducts(await api.list());
      setError('');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const kpis = useMemo(() => {
    const value = products.reduce((s, p) => s + p.price_inr * p.stock_quantity, 0);
    return [
      { label: 'Total products', value: products.length, tone: 'indigo' },
      { label: 'Inventory value', value: formatINR(value), tone: 'teal' },
      { label: 'Low stock', value: products.filter((p) => p.status === 'Low Stock').length, tone: 'amber' },
      { label: 'Out of stock', value: products.filter((p) => p.status === 'Out of Stock').length, tone: 'red' },
    ];
  }, [products]);

  const categories = useMemo(() => [...new Set(products.map((p) => p.category))].sort(), [products]);

  const handleSave = async (data) => {
    if (modal.mode === 'add') {
      await api.create(data);
      notify('Product add ho gaya');
    } else {
      await api.update(modal.product.product_id, data);
      notify('Product update ho gaya');
    }
    setModal(null);
    await load();
  };

  const handleDelete = async (p) => {
    if (!window.confirm(`"${p.product_name}" delete karna hai?`)) return;
    try {
      await api.remove(p.product_id);
      notify('Product delete ho gaya');
      await load();
    } catch (e) {
      notify(e.message, 'err');
    }
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!window.confirm('Isse current data replace ho jayega. Continue?')) return;
    try {
      const { rows, skipped } = await api.importFile(file);
      notify(`${rows} rows import hue${skipped ? `, ${skipped} invalid skip hui` : ''}`);
      await load();
    } catch (err) {
      notify(err.message, 'err');
    }
  };

  return (
    <div className="page">
      <header className="top">
        <div>
          <h1>Inventory Dashboard</h1>
          <p className="muted">Excel data se live — add, edit, delete aur charts</p>
        </div>
        <div className="actions">
          <input ref={fileRef} type="file" accept=".xlsx" hidden onChange={handleImport} />
          <button className="btn ghost" onClick={() => fileRef.current.click()}>Import Excel</button>
          <a className="btn ghost" href="/api/export">Export Excel</a>
          <button className="btn primary" onClick={() => setModal({ mode: 'add' })}>+ Add product</button>
        </div>
      </header>

      {error && <div className="banner">Server se data nahi aa raha: {error}</div>}

      <section className="kpis">
        {kpis.map((k) => (
          <div key={k.label} className={`kpi ${k.tone}`}>
            <span className="muted">{k.label}</span>
            <strong>{loading ? '…' : k.value}</strong>
          </div>
        ))}
      </section>

      <Charts products={products} />

      <ProductTable
        products={products}
        categories={categories}
        loading={loading}
        onEdit={(product) => setModal({ mode: 'edit', product })}
        onDelete={handleDelete}
      />

      {modal && (
        <ProductForm
          mode={modal.mode}
          product={modal.product}
          categories={categories}
          onSave={handleSave}
          onClose={() => setModal(null)}
        />
      )}

      {toast && <div className={`toast ${toast.type}`}>{toast.text}</div>}
    </div>
  );
}

import { useMemo, useState } from 'react';
import { formatINR } from '../utils.js';

const COLUMNS = [
  { key: 'product_id', label: 'ID' },
  { key: 'product_name', label: 'Product' },
  { key: 'category', label: 'Category' },
  { key: 'price_inr', label: 'Price', num: true },
  { key: 'stock_quantity', label: 'Stock', num: true },
  { key: 'status', label: 'Status' },
  { key: 'last_updated', label: 'Updated' },
];
const badge = { Active: 'ok', 'Low Stock': 'warn', 'Out of Stock': 'bad' };

export default function ProductTable({ products, categories, loading, onEdit, onDelete }) {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [status, setStatus] = useState('');
  const [sort, setSort] = useState({ key: 'product_id', dir: 1 });
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);

  const reset = (setter) => (e) => {
    setter(e.target.value);
    setPage(1);
  };

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    return products
      .filter((p) => !cat || p.category === cat)
      .filter((p) => !status || p.status === status)
      .filter((p) => !term || p.product_name.toLowerCase().includes(term) || String(p.product_id).includes(term))
      .sort((a, b) => {
        const x = a[sort.key];
        const y = b[sort.key];
        return (typeof x === 'number' ? x - y : String(x).localeCompare(String(y))) * sort.dir;
      });
  }, [products, q, cat, status, sort]);

  const pages = Math.max(1, Math.ceil(rows.length / size));
  const cur = Math.min(page, pages);
  const start = (cur - 1) * size;
  const visible = rows.slice(start, start + size);

  const toggleSort = (key) => setSort((s) => (s.key === key ? { key, dir: -s.dir } : { key, dir: 1 }));

  return (
    <section className="card">
      <div className="card-head">
        <h2>Products <span className="muted">({rows.length})</span></h2>
        <div className="controls">
          <input placeholder="Search name ya ID…" value={q} onChange={reset(setQ)} />
          <select value={cat} onChange={reset(setCat)}>
            <option value="">All categories</option>
            {categories.map((c) => <option key={c}>{c}</option>)}
          </select>
          <select value={status} onChange={reset(setStatus)}>
            <option value="">All status</option>
            <option>Active</option>
            <option>Low Stock</option>
            <option>Out of Stock</option>
          </select>
        </div>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              {COLUMNS.map((c) => (
                <th key={c.key} className={c.num ? 'num' : ''} onClick={() => toggleSort(c.key)}>
                  {c.label}
                  {sort.key === c.key && <span className="arrow">{sort.dir === 1 ? ' ▲' : ' ▼'}</span>}
                </th>
              ))}
              <th />
            </tr>
          </thead>
          <tbody>
            {visible.map((p) => (
              <tr key={p.product_id}>
                <td className="muted">{p.product_id}</td>
                <td><b>{p.product_name}</b></td>
                <td>{p.category}</td>
                <td className="num">{formatINR(p.price_inr)}</td>
                <td className="num">{p.stock_quantity}</td>
                <td><span className={`badge ${badge[p.status] || ''}`}>{p.status}</span></td>
                <td className="muted">{p.last_updated}</td>
                <td className="row-actions">
                  <button className="link" onClick={() => onEdit(p)}>Edit</button>
                  <button className="link danger" onClick={() => onDelete(p)}>Delete</button>
                </td>
              </tr>
            ))}
            {!visible.length && (
              <tr>
                <td colSpan={8} className="empty">{loading ? 'Loading…' : 'Koi product nahi mila'}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="pager">
        <span className="muted">
          {rows.length ? `${start + 1}–${Math.min(start + size, rows.length)} of ${rows.length}` : '0 results'}
        </span>
        <div className="controls">
          <select value={size} onChange={(e) => { setSize(Number(e.target.value)); setPage(1); }} aria-label="Rows per page">
            {[10, 25, 50, 100].map((n) => <option key={n} value={n}>{n} / page</option>)}
          </select>
          <button className="btn ghost" disabled={cur <= 1} onClick={() => setPage(cur - 1)}>Prev</button>
          <span className="page-no">Page {cur} / {pages}</span>
          <button className="btn ghost" disabled={cur >= pages} onClick={() => setPage(cur + 1)}>Next</button>
        </div>
      </div>
    </section>
  );
}

import { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { buildBins, summary, formatINR } from '../utils.js';

const FIELDS = {
  price_inr: { label: 'Price (₹)', widths: [250, 500, 1000, 2000], def: 1000, fmt: formatINR },
  stock_quantity: { label: 'Stock', widths: [10, 20, 25, 50], def: 20, fmt: (n) => Math.round(n) },
};
const STATUS_COLORS = { Active: '#16a34a', 'Low Stock': '#f59e0b', 'Out of Stock': '#ef4444' };
const BAR = '#6366f1';

export default function Charts({ products }) {
  const [field, setField] = useState('price_inr');
  const [width, setWidth] = useState(FIELDS.price_inr.def);
  const cfg = FIELDS[field];

  const values = useMemo(() => products.map((p) => p[field]).filter(Number.isFinite), [products, field]);
  const bins = useMemo(() => buildBins(values, width), [values, width]);
  const stats = useMemo(() => summary(values), [values]);

  const byCategory = useMemo(() => {
    const m = {};
    products.forEach((p) => (m[p.category] = (m[p.category] || 0) + 1));
    return Object.entries(m)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }, [products]);

  const byStatus = useMemo(() => {
    const m = {};
    products.forEach((p) => (m[p.status] = (m[p.status] || 0) + 1));
    return Object.entries(m).map(([name, value]) => ({ name, value }));
  }, [products]);

  const switchField = (f) => {
    setField(f);
    setWidth(FIELDS[f].def);
  };

  return (
    <section className="charts">
      <div className="card span2">
        <div className="card-head">
          <div>
            <h2>Histogram</h2>
            <p className="muted">{cfg.label} ka distribution</p>
          </div>
          <div className="controls">
            <div className="seg">
              {Object.entries(FIELDS).map(([key, f]) => (
                <button key={key} className={field === key ? 'on' : ''} onClick={() => switchField(key)}>
                  {f.label}
                </button>
              ))}
            </div>
            <select value={width} onChange={(e) => setWidth(Number(e.target.value))} aria-label="Bin width">
              {cfg.widths.map((w) => (
                <option key={w} value={w}>Bin: {w}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="chart-box">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={bins} barCategoryGap="3%" margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 12 }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
              <Tooltip formatter={(v) => [v, 'Products']} labelFormatter={(l) => `${cfg.label}: ${l}`} />
              <Bar dataKey="count" fill={BAR} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        {stats && (
          <div className="stats">
            <span>Min <b>{cfg.fmt(stats.min)}</b></span>
            <span>Median <b>{cfg.fmt(stats.median)}</b></span>
            <span>Average <b>{cfg.fmt(stats.avg)}</b></span>
            <span>Max <b>{cfg.fmt(stats.max)}</b></span>
          </div>
        )}
      </div>

      <div className="card">
        <h2>Stock status</h2>
        <p className="muted">Products ki halat</p>
        <div className="chart-box">
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={byStatus} dataKey="value" nameKey="name" innerRadius={58} outerRadius={92} paddingAngle={3}>
                {byStatus.map((s) => (
                  <Cell key={s.name} fill={STATUS_COLORS[s.name] || '#94a3b8'} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card span3">
        <h2>Products per category</h2>
        <div className="chart-box">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={byCategory} layout="vertical" margin={{ left: 20, right: 16 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12 }} />
              <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 12 }} />
              <Tooltip formatter={(v) => [v, 'Products']} />
              <Bar dataKey="count" fill="#14b8a6" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </section>
  );
}

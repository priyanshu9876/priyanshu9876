import { useState } from 'react';
import { statusFor } from '../utils.js';

export default function ProductForm({ mode, product, categories, onSave, onClose }) {
  const [f, setF] = useState({
    product_name: product?.product_name ?? '',
    category: product?.category ?? '',
    price_inr: product?.price_inr ?? '',
    stock_quantity: product?.stock_quantity ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const stockNum = Number(f.stock_quantity);
  const preview = f.stock_quantity === '' ? '—' : statusFor(stockNum);

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    setSaving(true);
    try {
      await onSave({
        ...f,
        price_inr: Number(f.price_inr),
        stock_quantity: Number(f.stock_quantity),
      });
    } catch (ex) {
      setErr(ex.message);
      setSaving(false);
    }
  };

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form className="modal" onSubmit={submit}>
        <h2>{mode === 'add' ? 'Add product' : `Edit product #${product.product_id}`}</h2>

        <label>Product name
          <input required autoFocus value={f.product_name} onChange={set('product_name')} />
        </label>

        <label>Category
          <input required list="cats" value={f.category} onChange={set('category')} />
          <datalist id="cats">{categories.map((c) => <option key={c} value={c} />)}</datalist>
        </label>

        <div className="two">
          <label>Price (₹)
            <input required type="number" min="0" step="any" value={f.price_inr} onChange={set('price_inr')} />
          </label>
          <label>Stock
            <input required type="number" min="0" step="1" value={f.stock_quantity} onChange={set('stock_quantity')} />
          </label>
        </div>

        <p className="muted small">Status apne aap set hoga: <b>{preview}</b> (0 = Out of Stock, 1–10 = Low Stock)</p>
        {err && <div className="banner">{err}</div>}

        <div className="modal-actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn primary" disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
        </div>
      </form>
    </div>
  );
}
